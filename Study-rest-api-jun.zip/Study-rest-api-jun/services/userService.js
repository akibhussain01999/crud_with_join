const pool=require('../lib/config');



// =======LIST USER BY ID=============================

module.exports.getuserdatabyid = (user_id) => {
 
  return new Promise((resolve, reject) => {
      pool.query('select um."email",um."fname",um."lname",um."mobile_no",um."status", d."dep_name" from user_master um'+
      ' inner join department d on (um."dep_id" =d."dep_id") where um."user_id" = ($1)', [user_id]).then((result) => {
         resolve(result.rows);
      }).catch((err) => {
          reject(err);
      })
  })
}



// ================================ALL USER LIST====================================

    module.exports.getuserdata = () => {
      return new Promise((resolve, reject) => {
      pool.query('select um.*, d."dep_name" from user_master um'+
      ' inner join department d on (um."dep_id" =d."dep_id") order by um.updated_at DESC').then((result) => {
      resolve(result.rows);
      }).catch((err) => {
      reject(err);
      })
      })
      }



// ================================ADD USER ====================================
module.exports.adduser=(user_id,email,fname,lname,mobile_no,status,dep_id)=>{
return new Promise ((resolve, reject)=>{
  var timestamp = new Date().getTime();
  pool.query('insert into user_master("user_id", "email","fname","lname","mobile_no","status","dep_id","created_at","created_by") values($1,$2,$3,$4,$5,$6,$7,Now(),$8)',[user_id,email,fname,lname,mobile_no,status,dep_id,email]).then((result) => {  

  resolve(result.rows);
      }).catch((err) => {
      reject(err);
      })
      })
      }



      // ============EDIT USER DATA==============================



      module.exports.edituser=(user_id,email,fname,lname,mobile_no,status)=>{
        return new Promise((resolve,reject)=>{

        pool.query('update user_master SET "email"=$1,"fname"=$2,"lname"=$3, "mobile_no"=$4, "status"=$5,"updated_at"= now(),"updated_by"= $6 where "user_id"=$7',[email,fname,lname,mobile_no,status,email,user_id]).then((result)=>{
        resolve(result.rows);


        }).catch((err)=>{
        reject(err);

        })

        });


        }










// ================================ALL DEPARTMENT LIST====================================

          module.exports.getdepartmentlist = () => {
            return new Promise((resolve, reject) => {
            pool.query('SELECT *FROM department').then((result) => {
            resolve(result.rows);

            }).catch((err) => {
            reject(err);
            })
            })
            }

        // =======================================ADD DEPARTMENT ==========================

        module.exports.adddepartment=(dep_id,dep_name,d_address,status,city,pincode,email)=>{
          return new Promise ((resolve, reject)=>{
            var timestamp = new Date().getTime();
            pool.query('insert into department("dep_id","dep_name","d_address","status","city","pincode","email","created_at","created_by") values($1,$2,$3,$4,$5,$6,$7,Now(),$8)',[dep_id,dep_name,d_address,status,city,pincode,email,email]).then((result) => {  
          
            resolve(result.rows);
                }).catch((err) => {
                reject(err);
                })
                })
                }



                  // ============EDIT DEPARTMENT DATA==============================



 module.exports.editdepartment=(dep_id,dep_name,d_address,status,city,pincode,email)=>{
   return new Promise((resolve,reject)=>{

    pool.query('update department SET "dep_name"=$1,"d_address"=$2,"status"=$3, "city"=$4, "pincode"=$5,"email"=$6, "updated_at"= now(),"updated_by"= $7 where "dep_id"=$8',[dep_name,d_address,status,city,pincode,email,email,dep_id]).then((result)=>{
      resolve(result.rows);

     }).catch((err)=>{
        reject(err);

    })

 });

}
            



   
                



                  // module.exports.searchbycolumnname = (user_id,email,fname,lname,mobile_no) => {

                  //   return new Promise((resolve, reject) => {
                  //     pool.query('SELECT *FROM user_master where user_id = $1 or email= $2 or fname =$3 or lname =$4 or mobile_no = $5',[user_id,email,fname,lname,mobile_no]).then((result) => {
                  //         console.log(result.rows[0])
                  //         resolve(result.rows);

                  //       }).catch((err)=>{
                  //       reject(err);
      
                  //       })
      
                  //       });
      
      
                  //       }


// working code search only user_master table

//  module.exports.searchbycolumnname = (searchString,pageNo) => {
//    let pageSize = 3;
//    let pageStart = pageNo * pageSize;
  
//    return new Promise((resolve, reject) => {        
//      pool.query('select um.*, count(*) OVER() AS total_records from user_master um where (um."email" ILike $3  or $3 is Null) or (um."fname" ILike $3 or $3 is Null) or (um."lname" ILike $3  or $3 is Null) or (um."mobile_no" ILike $3  or $3 is Null) or (um."user_id" ILike $3  or $3 is Null) '+'order by um."created_at" Desc limit $1 offset $2', [pageSize, pageStart,searchString]).then((result) => {
//      console.log(result.rows[0])
//        resolve(result.rows);
           
//     }).catch((err)=>{
//        reject(err);
                 
//      })
                 
//     });
                 
                 
//   }


module.exports.searchbycolumnname = (SearchString,PageNo) => {
   var SearchString = '%'+SearchString+'%';
  let PageSize = 3;
  let PageStart = PageNo * PageSize;
 
  return new Promise((resolve, reject) => {        
    pool.query('select um.*, d."dep_name", count(*) OVER() AS total_records from user_master  um inner join department d on (um."dep_id" =d."dep_id") where (um."email" ILike $3  or $3 is Null) or (um."fname" ILike $3 or $3 is Null) or (um."lname" ILike $3  or $3 is Null) or (um."mobile_no" ILike $3  or $3 is Null) or (d."dep_name" ILike $3  or $3 is Null) '+'order by um."user_id" ASC limit $1 offset $2', [PageSize, PageStart,SearchString]).then((result) => {
    console.log(result.rows[0])
      resolve(result.rows);
          
   }).catch((err)=>{
      reject(err);
                
    })
                
   });
                
                
 }



// module.exports.searchbycolumnname = (searchString,pageNo) => {
//   let pageSize = 3;
//   let pageStart = pageNo * pageSize;
 
//   return new Promise((resolve, reject) => {        
//     pool.query('select um.*, d."dep_name", count(*) OVER() AS total_records from user_master um inner join department d on (um."dep_id" =d."dep_id") where (um."email" ILike $3  or $3 is Null) '+'order by um."created_at" Desc limit $1 offset $2', [pageSize, pageStart,searchString]).then((result) => {
//     console.log(result.rows[0])
//       resolve(result.rows);
          
//    }).catch((err)=>{
//       reject(err);
                
//     })
                
//    });
                
                
 //}
           
