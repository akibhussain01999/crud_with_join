const pool = require('../lib/postgresDb'); //access the database connection pool
const pool2 = require('../lib/postgresDbCommon'); //access the database connection pool
const pool3 = require('../lib/postgresDbCompany');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const https = require('https');
var _ = require('lodash');
const xlsx = require('xlsx');

var addRecipient = (company_id, schema, email, recipient_code, recipient_type, recipient_status) => {
    return new Promise((resolve, reject) => {
        pool.query('INSERT INTO "' + schema + '"' + '.tag_details (tag_name, tag_type, created_by, created_at, status, updated_by, updated_at, company_id, created_at_unix) values ($1, $2, $3, now(), $4, $5, now(), $6, $7) returning tag_id', [tag_name, tag_type, created_by, 1, created_by, company_id, parseInt(Date.now() / 1000)]).then((res) => {
            resolve(res.rows);
        }).catch((err) => {
            reject(err);
        });
    })
}


// var getrecipientlist = (schema) => {
//     return new Promise((resolve, reject) => {
//         pool.query('SELECT rd.* FROM "' + schema + '"' + '.recipient_details rd '+
//          'order by recipient_id ASC ')
//             .then((result) => {
//                 resolve(result.rows);
//             }).catch((err) => {
//                 reject(err);
//             });
//     })
// }



var getrecipientlist = (pageNo, schema) => {
    let pageSize = 25;
    let pageStart = pageNo * pageSize;

    return new Promise((resolve, reject) => {
        pool.query('select rd.recipient_code,rd.recipient_name, rd.recipient_type, rd.created_by, rd.created_at, rd.recipient_status,count(*) OVER() AS total_records FROM "' + schema + '"' + '.recipient_details rd left join "' + schema + '"' + '.recipient_address_details rad ON (rd.recipient_id = rad.recipient_id) left join "' + schema + '"' + '.recipient_sale_details rsd ON (rsd.recipient_id = rad.recipient_id) order by rd.recipient_id limit $1 offset $2', [pageSize, pageStart])
        .then((result) => {
                resolve(result.rows);
            }).catch((err) => {
                reject(err);
            });
    })
}

// var recipient = (page_no, page_count, sort_on, sort_by,schema, search_string) => {
//     if (search_string == "undefined" || search_string == "") { search_string = null; } else { search_string = '%' + search_string + '%' }
//     let page_size = page_count;
//     let page_start = page_no * page_size;
//     return new Promise((resolve, reject) => {
//         pool.query('Select rd.*, count(*) OVER() AS total_records from "' + schema + '"' + '.recipient_details rd ' +
//             ' where (rd."recipient_name" ILIKE $3  or $3 is null) order by ' + sort_on + ' ' + sort_by + ' limit $1 offset $2 ', [page_size, page_start, search_string]).then((result) => {
//                 resolve(result.rows);
//             }).catch((err) => {
//                 reject(err);
//             })
//     })
// }

// working code
// var recipient = (page_no, page_count,schema, search_string) => {
//     if (search_string == "undefined" || search_string == "") { search_string = null; } else { search_string = '%' + search_string + '%' }
//     let page_size = page_count;
//     let page_start = page_no * page_size;
//     return new Promise((resolve, reject) => {
//         pool.query('Select rd.*, count(*) OVER() AS total_records from "' + schema + '"' + '.recipient_details rd ' +' where (rd."recipient_name" ILIKE $3  or $3 is null) order by  rd."recipient_id" limit $1 offset $2 ', [page_size, page_start, search_string]).then((result) => {
//                 resolve(result.rows);
//             }).catch((err) => {
//                 reject(err);
//             })
//     })
// }

// select rd.recipient_code,rd.recipient_name, rd.recipient_type, rd.created_by, rd.created_at, rd.recipient_status,count(*) OVER() AS total_records FROM "' + schema + '"' + '.recipient_details rd left join "' + schema + '"' + '.recipient_address_details rad ON (rd.recipient_id = rad.recipient_id) left join "' + schema + '"' + '.recipient_sale_details rsd ON (rsd.recipient_id = rad.recipient_id) order by rd.recipient_id limit $1 offset $2'

var recipient = (page_no, page_count,schema, search_string) => {
    if (search_string == "undefined" || search_string == "") { search_string = null; } else { search_string = '%' + search_string + '%' }
    let page_size = page_count;
    let page_start = page_no * page_size;
    return new Promise((resolve, reject) => {
        pool.query('select rd.recipient_code,rd.recipient_name, rd.recipient_type, rd.created_by, rd.created_at, rd.recipient_status,count(*) OVER() AS total_records FROM "' + schema + '"' + '.recipient_details rd left join "' + schema + '"' + '.recipient_address_details rad ON (rd.recipient_id = rad.recipient_id) left join "' + schema + '"' + '.recipient_sale_details rsd ON (rsd.recipient_id = rad.recipient_id)' +' where (rd."recipient_name" ILIKE $3  or $3 is null) order by  rd."recipient_id" limit $1 offset $2 ', [page_size, page_start, search_string]).then((result) => {
                resolve(result.rows);
            }).catch((err) => {
                reject(err);
            })
    })
}

module.exports = {
    addRecipient: addRecipient,
    getrecipientlist:getrecipientlist,
    recipient:recipient
}