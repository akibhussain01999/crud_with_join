var express = require('express');
var router = express.Router();
const jwt = require('express-jwt');
const auth = jwt({ secret: 'PRAMOD', userProperty: 'payload' });
const recipientService = require('../../services/recipientService');
const request = require('request');
const AWS = require('aws-sdk');
const multerS3 = require('multer-s3');
const multer = require('multer');

// Adding a recipient
router.post('/addrecipient', auth, (req, res, next) => {
	var schema = req.payload.company_code;
	recipientService.addRecipient(req.payload.company_id, schema, req.payload.email, req.body.recipient_code, req.body.recipient_type, req.body.recipient_status).then((result) => {
		res.json({ status_code: 200, message: "Recipient added successfully", data: result });
	}).catch((err) => {
		res.status(400).json({ message: "Error occured", data: err })
	})
});


// Get all recipient list
router.get('/getrecipientlist', auth, (req, res, next) => {
	var schema = req.payload.company_code;
	recipientService.getrecipientlist(req.query.pageNo,schema).then((result) => {
		res.json({ status_code: 200, message: "recipient list success", data: result });
	}).catch((err) => {
		res.status(400).json({ status_code: 400, message: 'Error occured.', data: err });
	})
});



//Search recipint by name
router.get('/Searchrecipient', auth, (req, res, next) => {
	var schema = req.payload.company_code;
	recipientService.recipient(req.query.page_no, req.query.page_count,schema, req.query.search_string).then((result) => {
		res.json({ status_code: 200, message: "Search recipient success", data: result });
	}).catch((err) => {
		res.status(400).json({ status_code: 400, message: 'Error occured.', data: err });
	})
});




module.exports = router;