
var express = require('express');
var router = express.Router();
require('../lib/config');
const userservice=require('../services/userService');



// ==============GET USER BY ID==================

router.get('/getuserdatabyid', (req, res, next) => {
    userservice.getuserdatabyid(req.query.user_id)
    .then((result) => {
        res.json({message: "User list", data: result});
    })
    .catch((err) => {
        res.status(400).json({message: "error occured.", data: err});
    })
});


// ==============GET ALL USER==================

router.get('/getuserdata', (req, res, next) => {
    userservice.getuserdata()
    .then((result) => {
    res.json({message: "User list", data: result});
    })
    .catch((err) => {
    res.status(400).json({message: "error occured.", data: err});
    })
    });



    // ==============ADD USER==================


        router.post('/adduser',(req,res,next)=>{
        userservice.adduser(req.body.user_id,req.body.email,req.body.fname,req.body.lname,req.body.mobile_no,req.body.status,req.body.dep_id).then((result)=>{
            res.json({message: "User added successfully.", data:result});
        })
        .catch((err) => {
        res.status(400).json({message: "error occured.", data: err});


        })


        });
// ========================EDIT USER DATA===========================


router.post('/edituser',(req,res,next)=>{
    userservice.edituser(req.query.user_id,req.body.email,req.body.fname,req.body.lname,req.body.mobile_no,req.body.status).then((result)=>{
        res.json({message: "User info updated successfully", data: result});
    })
    .catch((err) => {
    res.status(400).json({message: "error occured.", data: err});


    })


    });




// ==============GET ALL DEPARTMENT LIST==================

router.get('/getdepartmentlist', (req, res, next) => {
    userservice.getdepartmentlist()
    .then((result) => {
    res.json({message: "Department list", data: result});
    })
    .catch((err) => {
    res.status(400).json({message: "error occured.", data: err});
    })
    });



    // =========================ADD DEPARTMENT================================

  

    router.post('/adddepartment',(req,res,next)=>{
        userservice.adddepartment(req.body.dep_id,req.body.dep_name,req.body.d_address,req.body.status,req.body.city,req.body.pincode,req.body.email).then((result)=>{
            res.json({message: "Department added successfully.", data:result});
        })
        .catch((err) => {
        res.status(400).json({message: "error occured.", data: err});


        })


        });


        // ========================EDIT DEPARTMENT DATA===========================


router.post('/editdepartment',(req,res,next)=>{
    userservice.editdepartment(req.query.dep_id,req.body.dep_name,req.body.d_address,req.body.status,req.body.city,req.body.pincode,req.body.email).then((result)=>{
       
        res.json({message: "Department info updated successfully", data: result});
    })
    .catch((err) => {
    res.status(400).json({message: "error occured.", data: err});


    })


    });












    // ====================================SEARCH BY COLUMN NAME ======================================


    // router.get('/searchbycolumnname',(req, res, next) => {
    //     userservice.searchbycolumnname(req.query.user_id, req.query.email, req.query.fname, req.query.lname, req.query.mobile_no)
    //     .then((result) => {
    //         res.json({message:"search result.", data: result});
    //     })
    //     .catch((err) => {
    //         res.status(400).json({message: "error occured.", data: err});
    //     })
    // });



    router.post('/searchbycolumnname',(req, res, next) => {
        // var SearchString = '%'+req.body.SearchString+'%';
        userservice.searchbycolumnname(req.body.SearchString,req.body.PageNo)
        .then((result) => {
            res.json({message:"search result.", data: result});
        })
        .catch((err) => {
            res.status(400).json({message: "error occured.", data: err});
        })
    });

module.exports=router;





//810276101











