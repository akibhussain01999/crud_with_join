const express=require('express');
const app = express();
const port=4000;
 require('./lib/config');

 

 const swaggerUi = require('swagger-ui-express');
 const swaggerDocument = require('./swagger.json');

const bodyparser=require('body-parser');
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true,}))




const userModule=require('./route/userModule');
app.use('/userModule',userModule);




//  example of syncrouns
// var fs = require("fs");
// var data=fs.readFileSync('input.txt');
// console.log(data.toString());

// example of assyncrouns
// var fs = require("fs");

// fs.readFile('input.txt', function (err, data) {
//    if (err) 
//    return console.error(err);
//    console.log(data.toString());
// });

// console.log("Program Ended");



app.listen(port,()=>{
    app.use('/swagger', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
console.log(`app is running on ${port}`);

})




module.exports=app;